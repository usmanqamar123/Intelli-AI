<?php
/**
 * Plugin Name: Intelliwriter
 * Plugin URI: https://wordpress.org/plugins/intelliwriter
 * Description: Intelliwriter is a powerful WordPress plugin that allows you to publish generated articles directly from Intelliwriter.io to your WordPress site with just one click. Seamlessly integrate your WordPress dashboard with Intelliwriter’s advanced AI writing tools and automate your content publishing workflow.
 * Version: 1.0
 * Author: Robx.ai
 * Author URI: https://robx.ai/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 5.6
 * Tested up to: 6.7
 * Requires PHP: 8.2.11
 * Text Domain: intelliwriter
 */

if (!defined('ABSPATH')) {
    exit; 
}

// Hook to add menu item under Settings
add_action('admin_menu', 'intelliwriter_add_admin_menu');

function intelliwriter_add_admin_menu() {
    add_options_page(
        'Intelliwriter Settings',  
        'Intelliwriter',          
        'manage_options',          
        'intelliwriter',           
        'intelliwriter_display_page' 
    );
}

/// Callback function to display the Intelliwriter settings page
function intelliwriter_display_page() {
    wp_cache_delete('intelliwriter_connection_status', 'options');

    $connection_status = get_option('intelliwriter_connection_status', 'disconnected');
    $is_connected = ($connection_status === 'connected');
    ?>
    <div class="wrap">
        <img src="<?php echo plugin_dir_url(__FILE__) . 'assets/logo.png'; ?>" alt="Intelliwriter Logo" style="max-width: 200px; display: block; margin-bottom: 20px;">

        <p>
            <strong>New to Intelliwriter?</strong> 
            <a href="https://app.intelliwriter.io/auth/register" target="_blank">Register</a>
        </p>

        <?php if (!$is_connected): ?>
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" target="_blank">
                <input type="hidden" name="action" value="connect_intelliwriter">
                <?php wp_nonce_field('connect_intelliwriter_nonce', 'connect_intelliwriter_nonce'); ?>
                <input type="submit" class="button-primary" value="Connect">
            </form>
        <?php else: ?>
            <p style="color: green;"><strong>Connected to Intelliwriter!</strong></p>
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                <input type="hidden" name="action" value="disconnect_intelliwriter">
                <?php wp_nonce_field('disconnect_intelliwriter_nonce', 'disconnect_intelliwriter_nonce'); ?>
                <input type="submit" class="button-secondary" value="Disconnect">
            </form>
        <?php endif; ?>
    </div>
    <?php
}


add_action('admin_post_connect_intelliwriter', 'handle_connect_intelliwriter');

function handle_connect_intelliwriter() {
    if (!isset($_POST['connect_intelliwriter_nonce']) || !wp_verify_nonce($_POST['connect_intelliwriter_nonce'], 'connect_intelliwriter_nonce')) {
        wp_die('Security check failed');
    }

    add_filter('wp_is_application_passwords_available', '__return_true');

    $current_user = wp_get_current_user();
    $user_email = $current_user->user_email;
    $site_url = get_site_url();

    if (class_exists('WP_Application_Passwords')) {
        list($password, $item) = WP_Application_Passwords::create_new_application_password($current_user->ID, [
            'name' => 'IntelliWriter Integration'
        ]);

        if (!$password) {
            wp_die('Could not generate application password.');
        }
    } else {
        wp_die('WP_Application_Passwords class is not available.');
    }

    // Token (optional)
    $token = bin2hex(random_bytes(32)); 

    // update_option('intelliwriter_auth_token', $token);
    update_option('intelliwriter_auth_password', $password);
    update_option('intelliwriter_user_email', $user_email);
    update_option('intelliwriter_site_url', $site_url);
    update_option('intelliwriter_connection_status', 'connected');

    $redirect_url = add_query_arg([
        'domain'       => urlencode($site_url),
        'user'         => urlencode($user_email),
        // 'token'        => $token,
        'password' => $password,
    ], 'https://app.intelliwriter.io/wordpress-authentication');

    wp_redirect($redirect_url);
    exit;
}

// Handle token verification when the user returns from Intelliwriter
add_action('init', 'intelliwriter_verify_password_on_return');

function intelliwriter_verify_password_on_return() {
    if (isset($_GET['password']) && isset($_GET['domain']) && isset($_GET['user'])) {
        $received_token = sanitize_text_field($_GET['password']);
        $received_domain = sanitize_text_field($_GET['domain']);
        $received_user = sanitize_text_field($_GET['user']);

        $stored_received_token = get_option('intelliwriter_auth_password');
        $stored_site_url = get_option('intelliwriter_site_url');
        $stored_user_email = get_option('intelliwriter_user_email');

        if ($received_received_token === $stored_received_token && $received_domain === $stored_site_url && $received_user === $stored_user_email) {
            update_option('intelliwriter_connection_status', 'connected'); 
            wp_redirect(admin_url('options-general.php?page=intelliwriter')); 
            exit;
        } else {
            wp_die('Invalid password or domain mismatch. Authentication failed.');
        }
    }
}

add_action('admin_post_disconnect_intelliwriter', 'handle_disconnect_intelliwriter');

function handle_disconnect_intelliwriter() {
    if (!isset($_POST['disconnect_intelliwriter_nonce']) || !wp_verify_nonce($_POST['disconnect_intelliwriter_nonce'], 'disconnect_intelliwriter_nonce')) {
        wp_die('Security check failed');
    }

    // Delete all stored options related to the connection
    delete_option('intelliwriter_auth_password');
    delete_option('intelliwriter_user_email');
    delete_option('intelliwriter_site_url');
    update_option('intelliwriter_connection_status', 'disconnected');

    wp_cache_delete('alloptions', 'options');

    wp_redirect(admin_url('options-general.php?page=intelliwriter'));
    exit;
}



// Register the validate-user API route
add_action('rest_api_init', 'intelliwriter_register_api_routes');

function intelliwriter_register_api_routes() {
    register_rest_route('intelliwriter/v1', '/validate-user', array(
        'methods' => 'POST',
        'callback' => 'intelliwriter_validate_user',
        'permission_callback' => '__return_true', 
    ));
}

function intelliwriter_validate_user(WP_REST_Request $request) {
    $received_token = $request->get_param('password');
    $user_email = $request->get_param('user');
    $site_url = $request->get_param('domain');
    
    $stored_received_token = get_option('intelliwriter_auth_password');
    $stored_email = get_option('intelliwriter_user_email');
    $stored_site_url = get_option('intelliwriter_site_url');

    if ($received_token === $stored_received_token&& $user_email === $stored_email && $site_url === $stored_site_url) {
        return new WP_REST_Response('Validation successful', 200);
    } else {
        return new WP_REST_Response('Invalid password or mismatch', 400);
    }
}


// Register REST API endpoint for publishing articles
add_action('rest_api_init', function () {
    register_rest_route('intelliwriter/v1', '/publish-article', array(
        'methods'  => 'POST',
        'callback' => 'intelliwriter_publish_article',
        'permission_callback' => '__return_true',
    ));
});

function intelliwriter_publish_article(WP_REST_Request $request) {
    $password = $request->get_param('password');
    $title = sanitize_text_field($request->get_param('title'));
    $content = wp_kses_post($request->get_param('content'));
    $category_names = $request->get_param('categories'); 
    $status = $request->get_param('status');
    $date = $request->get_param('date');

    $stored_password = get_option('intelliwriter_auth_password');

    if (!$password || $password !== $stored_password) {
        return new WP_REST_Response(array('message' => 'Invalid authentication password'), 403);
    }

    if (!is_array($category_names)) {
        return new WP_REST_Response(array('message' => 'Invalid category format'), 400);
    }

    $category_ids = [];

    foreach ($category_names as $category_name) {
        $category_name = sanitize_text_field($category_name);

        // Check if category exists
        $category = get_term_by('name', $category_name, 'category');

        if (!$category) {
            $new_category = wp_insert_term($category_name, 'category');
            if (is_wp_error($new_category)) {
                return new WP_REST_Response(array(
                    'message' => 'Failed to create category',
                    'error' => $new_category->get_error_message()
                ), 500);
            }

            $category_ids[] = $new_category['term_id'];
        } else {
            $category_ids[] = $category->term_id;
        }
    }

    if ($status !== 'future') {
        $status = 'publish';
    }

    $post_date = current_time('mysql');
    $post_date_gmt = current_time('mysql', 1);

    if ($status === 'future' && $date) {
        $timestamp = strtotime($date);
        if ($timestamp && $timestamp > time()) {
            $post_date = gmdate('Y-m-d H:i:s', $timestamp);
            $post_date_gmt = get_gmt_from_date($post_date);
        } else {
            return new WP_REST_Response(array('message' => 'Scheduled time must be in the future'), 400);
        }
    }

    $post_data = array(
        'post_title'     => $title,
        'post_content'   => $content,
        'post_status'    => $status,
        'post_author'    => get_current_user_id(),
        'post_type'      => 'post',
        'post_category'  => $category_ids,
        'post_date'      => $post_date,
        'post_date_gmt'  => $post_date_gmt,
    );

    $post_id = wp_insert_post($post_data);

    if (is_wp_error($post_id)) {
        return new WP_REST_Response(array('message' => 'Failed to publish article'), 500);
    }

    return new WP_REST_Response(array(
        'message' => $status === 'future' ? 'Article scheduled successfully' : 'Article published successfully',
        'post_id' => $post_id
    ), 200);
}



function intelliwriter_register_routes() {
    register_rest_route('intelliwriter/v1', '/categories', array(
        'methods'  => 'GET',
        'callback' => 'intelliwriter_get_categories',
        'permission_callback' => '__return_true', 
    ));
}

function intelliwriter_get_categories() {
    $categories = get_categories(array(
        'hide_empty' => false,
    ));

    $data = array();

    foreach ($categories as $category) {
        $data[] = array(
            'id'   => $category->term_id,
            'name' => $category->name,
            'slug' => $category->slug,
        );
    }

    return new WP_REST_Response($data, 200);
}

add_action('rest_api_init', 'intelliwriter_register_routes');
