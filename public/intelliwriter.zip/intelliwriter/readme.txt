=== Intelliwriter ===
Tags: AI, content writing, article publishing, WordPress automation, blogging  
Requires at least: 5.6  
Tested up to: 6.7  
Requires PHP: 8.2.11  
Stable tag: 1.0  
License: GPLv2 or later  
License URI: https://www.gnu.org/licenses/gpl-2.0.html  

Publish AI-generated articles from Intelliwriter.io to your WordPress site in just one click! Seamlessly integrate and manage your content publishing workflow.

== Description ==

**Intelliwriter** is a powerful WordPress plugin that allows you to publish AI-generated articles directly from **Intelliwriter.io** to your WordPress site with just one click. 

Say goodbye to manual copying and pasting! With Intelliwriter, you can streamline your content creation workflow, saving time and effort.

**Key Features:**
✅ **One-Click Publishing** – Instantly publish AI-generated articles to WordPress.  
✅ **Secure Authentication** – Connect your Intelliwriter account securely with your site.  
✅ **Seamless Integration** – Manage and publish content from the Intelliwriter dashboard.  
✅ **Automatic Formatting** – Proper post structure and clean HTML formatting.  

**Where to Find the Plugin?**  
After installation, access Intelliwriter from your **WordPress Dashboard** under **Settings → Intelliwriter**.

== Installation ==

1. Download the plugin ZIP file or install it directly from the WordPress Plugin Directory.
2. Upload and activate the **Intelliwriter** plugin from your WordPress admin panel.
3. Navigate to **Settings → Intelliwriter** to connect your site with Intelliwriter.io.
4. Once connected, generate AI-powered content in **Intelliwriter.io** and publish it directly to your WordPress site.

== Frequently Asked Questions ==

= How do I connect my WordPress site to Intelliwriter? =  
Go to **Settings → Intelliwriter**, click **Connect**, and follow the authentication process.

= Do I need an Intelliwriter.io account to use this plugin? =  
Yes, you must have an active **Intelliwriter.io** account to generate and publish articles.

= Can I edit articles after publishing? =  
Yes! All published articles appear as WordPress posts, and you can edit them like any other post.

= Is my connection to Intelliwriter secure? =  
Yes, we use token-based authentication to ensure a secure connection.

== Changelog ==

= 1.0 =  
* Initial release of the Intelliwriter plugin.  
* Added one-click publishing from Intelliwriter.io.  
* Secure authentication with token-based verification.  

== Upgrade Notice ==

= 1.0 =  
Initial release – seamlessly publish AI-generated articles to your WordPress site.

== Screenshots ==

1. **Settings Page** – Easily connect your WordPress site to Intelliwriter.io.  
2. **One-Click Publishing** – Publish AI-generated articles instantly.  
3. **Published Post** – View and edit published articles directly in WordPress.

== Support ==

For support, visit [https://intelliwriter.io/contact](https://intelliwriter.io/contact).
